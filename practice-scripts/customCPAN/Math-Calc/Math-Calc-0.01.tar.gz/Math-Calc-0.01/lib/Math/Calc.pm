package Math::Calc;
use strict;
use warnings;

our $VERSION = '0.01';
 
sub add {
  return $_[0] + $_[1];
}
 
1;
